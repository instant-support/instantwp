package whatsapp

import (
	"context"
	"encoding/json"
	"fmt"
	"sort"
	"strconv"
	"strings"
	"time"
)

// SendTextMessage sends a text message to a phone number with optional reply context
func (c *Client) SendTextMessage(ctx context.Context, account *Account, phoneNumber, text string, replyToMsgID ...string) (string, error) {
	payload := map[string]any{
		"messaging_product": "whatsapp",
		"recipient_type":    "individual",
		"to":                phoneNumber,
		"type":              "text",
		"text": map[string]any{
			"preview_url": false,
			"body":        text,
		},
	}

	// Add reply context if provided
	if len(replyToMsgID) > 0 && replyToMsgID[0] != "" {
		payload["context"] = map[string]any{
			"message_id": replyToMsgID[0],
		}
	}

	url := c.buildMessagesURL(account)
	c.Log.Debug("Sending text message", "phone", phoneNumber, "url", url)

	respBody, err := c.doRequest(ctx, "POST", url, payload, account.AccessToken)
	if err != nil {
		c.Log.Error("Failed to send text message", "error", err, "phone", phoneNumber)
		return "", fmt.Errorf("failed to send text message: %w", err)
	}

	var resp MetaAPIResponse
	if err := json.Unmarshal(respBody, &resp); err != nil {
		return "", fmt.Errorf("failed to parse response: %w", err)
	}

	if len(resp.Messages) == 0 {
		return "", fmt.Errorf("no message ID in response")
	}

	messageID := resp.Messages[0].ID
	c.Log.Info("Text message sent", "message_id", messageID, "phone", phoneNumber)
	return messageID, nil
}

// SendInteractiveButtons sends an interactive message with buttons or list
// If buttons <= 3, sends as buttons; if 4-10, sends as list
func (c *Client) SendInteractiveButtons(ctx context.Context, account *Account, phoneNumber, bodyText string, buttons []Button) (string, error) {
	if len(buttons) == 0 {
		return "", fmt.Errorf("at least one button is required")
	}
	if len(buttons) > 10 {
		return "", fmt.Errorf("maximum 10 buttons allowed")
	}

	var interactive map[string]interface{}

	if len(buttons) <= 3 {
		// Use button format
		buttonsList := make([]map[string]interface{}, 0, len(buttons))
		for _, btn := range buttons {
			title := btn.Title
			if len(title) > 20 {
				title = title[:20]
			}
			buttonsList = append(buttonsList, map[string]interface{}{
				"type": "reply",
				"reply": map[string]interface{}{
					"id":    btn.ID,
					"title": title,
				},
			})
		}

		interactive = map[string]interface{}{
			"type": "button",
			"body": map[string]interface{}{
				"text": bodyText,
			},
			"action": map[string]interface{}{
				"buttons": buttonsList,
			},
		}
	} else {
		// Use list format for 4-10 items
		rows := make([]map[string]interface{}, 0, len(buttons))
		for _, btn := range buttons {
			title := btn.Title
			if len(title) > 24 {
				title = title[:24]
			}
			rows = append(rows, map[string]interface{}{
				"id":    btn.ID,
				"title": title,
			})
		}

		interactive = map[string]interface{}{
			"type": "list",
			"body": map[string]interface{}{
				"text": bodyText,
			},
			"action": map[string]interface{}{
				"button": "Select an option",
				"sections": []map[string]interface{}{
					{
						"title": "Options",
						"rows":  rows,
					},
				},
			},
		}
	}

	payload := map[string]interface{}{
		"messaging_product": "whatsapp",
		"recipient_type":    "individual",
		"to":                phoneNumber,
		"type":              "interactive",
		"interactive":       interactive,
	}

	url := c.buildMessagesURL(account)
	c.Log.Debug("Sending interactive message", "phone", phoneNumber, "button_count", len(buttons))

	respBody, err := c.doRequest(ctx, "POST", url, payload, account.AccessToken)
	if err != nil {
		c.Log.Error("Failed to send interactive message", "error", err, "phone", phoneNumber)
		return "", fmt.Errorf("failed to send interactive message: %w", err)
	}

	var resp MetaAPIResponse
	if err := json.Unmarshal(respBody, &resp); err != nil {
		return "", fmt.Errorf("failed to parse response: %w", err)
	}

	if len(resp.Messages) == 0 {
		return "", fmt.Errorf("no message ID in response")
	}

	messageID := resp.Messages[0].ID
	c.Log.Info("Interactive message sent", "message_id", messageID, "phone", phoneNumber)
	return messageID, nil
}

// SendCTAURLButton sends an interactive message with a CTA URL button
// This opens a URL when clicked instead of sending a reply
func (c *Client) SendCTAURLButton(ctx context.Context, account *Account, phoneNumber, bodyText, buttonText, url string) (string, error) {
	if buttonText == "" || url == "" {
		return "", fmt.Errorf("button text and URL are required")
	}

	// Truncate button text to 20 chars (WhatsApp limit)
	if len(buttonText) > 20 {
		buttonText = buttonText[:20]
	}

	interactive := map[string]interface{}{
		"type": "cta_url",
		"body": map[string]interface{}{
			"text": bodyText,
		},
		"action": map[string]interface{}{
			"name": "cta_url",
			"parameters": map[string]interface{}{
				"display_text": buttonText,
				"url":          url,
			},
		},
	}

	payload := map[string]interface{}{
		"messaging_product": "whatsapp",
		"recipient_type":    "individual",
		"to":                phoneNumber,
		"type":              "interactive",
		"interactive":       interactive,
	}

	apiURL := c.buildMessagesURL(account)
	c.Log.Debug("Sending CTA URL button message", "phone", phoneNumber, "url", url)

	respBody, err := c.doRequest(ctx, "POST", apiURL, payload, account.AccessToken)
	if err != nil {
		c.Log.Error("Failed to send CTA URL button message", "error", err, "phone", phoneNumber)
		return "", fmt.Errorf("failed to send CTA URL button message: %w", err)
	}

	var resp MetaAPIResponse
	if err := json.Unmarshal(respBody, &resp); err != nil {
		return "", fmt.Errorf("failed to parse response: %w", err)
	}

	if len(resp.Messages) == 0 {
		return "", fmt.Errorf("no message ID in response")
	}

	messageID := resp.Messages[0].ID
	c.Log.Info("CTA URL button message sent", "message_id", messageID, "phone", phoneNumber)
	return messageID, nil
}

// TemplateParam represents a parameter for template message
type TemplateParam struct {
	Type  string `json:"type"`
	Text  string `json:"text,omitempty"`
	Image *struct {
		Link string `json:"link"`
	} `json:"image,omitempty"`
	Document *struct {
		Link     string `json:"link"`
		Filename string `json:"filename"`
	} `json:"document,omitempty"`
	Video *struct {
		Link string `json:"link"`
	} `json:"video,omitempty"`
}

// SendTemplateMessage sends a template message
// BodyParamsToComponents converts a bodyParams map into WhatsApp template components.
// Supports both positional (numeric keys) and named parameters.
func BodyParamsToComponents(bodyParams map[string]string) []map[string]interface{} {
	if len(bodyParams) == 0 {
		return nil
	}

	// Check if using named parameters (non-numeric keys like "name", "order_id")
	isNamedParams := false
	for key := range bodyParams {
		if _, err := strconv.Atoi(key); err != nil {
			isNamedParams = true
			break
		}
	}

	// Get sorted keys for deterministic ordering
	keys := make([]string, 0, len(bodyParams))
	for k := range bodyParams {
		keys = append(keys, k)
	}
	sort.Strings(keys)

	params := make([]map[string]interface{}, 0, len(bodyParams))
	for _, key := range keys {
		param := map[string]interface{}{
			"type": "text",
			"text": bodyParams[key],
		}
		if isNamedParams {
			param["parameter_name"] = key
		}
		params = append(params, param)
	}

	return []map[string]interface{}{
		{
			"type":       "body",
			"parameters": params,
		},
	}
}

// BuildTemplateComponents builds the full WhatsApp template components array,
// including an optional header component (for IMAGE/VIDEO/DOCUMENT) and body parameters.
func BuildTemplateComponents(bodyParams map[string]string, headerType string, headerMediaID string) []map[string]interface{} {
	var components []map[string]interface{}

	// Add header component if media is provided
	if headerMediaID != "" {
		mediaType := strings.ToLower(headerType) // "image", "video", "document"
		headerParam := map[string]interface{}{
			"type": mediaType,
			mediaType: map[string]interface{}{
				"id": headerMediaID,
			},
		}
		components = append(components, map[string]interface{}{
			"type":       "header",
			"parameters": []map[string]interface{}{headerParam},
		})
	}

	// Add body component with text parameters
	bodyComponents := BodyParamsToComponents(bodyParams)
	components = append(components, bodyComponents...)

	if len(components) == 0 {
		return nil
	}
	return components
}

// ButtonURLParamsToComponents converts button parameters to WhatsApp API button components.
// buttonParams maps button index (as string like "0", "1") to the dynamic parameter value.
// templateButtons is the JSONB buttons array from the template, used to determine button type.
// URL buttons produce: {"type": "button", "sub_type": "url", "index": "0", "parameters": [{"type": "text", "text": "value"}]}
// COPY_CODE buttons produce: {"type": "button", "sub_type": "copy_code", "index": "0", "parameters": [{"type": "coupon_code", "coupon_code": "value"}]}
func ButtonURLParamsToComponents(buttonParams map[string]string, templateButtons ...[]interface{}) []map[string]interface{} {
	if len(buttonParams) == 0 {
		return nil
	}

	// Build a lookup of button index -> type from template buttons
	btnTypes := map[string]string{}
	if len(templateButtons) > 0 {
		for i, raw := range templateButtons[0] {
			if btn, ok := raw.(map[string]interface{}); ok {
				if t, ok := btn["type"].(string); ok {
					btnTypes[fmt.Sprintf("%d", i)] = strings.ToUpper(t)
				}
			}
		}
	}

	keys := make([]string, 0, len(buttonParams))
	for k := range buttonParams {
		keys = append(keys, k)
	}
	sort.Strings(keys)

	components := make([]map[string]interface{}, 0, len(buttonParams))
	for _, index := range keys {
		value := buttonParams[index]
		if btnTypes[index] == "COPY_CODE" {
			components = append(components, map[string]interface{}{
				"type":     "button",
				"sub_type": "copy_code",
				"index":    index,
				"parameters": []map[string]interface{}{
					{"type": "coupon_code", "coupon_code": value},
				},
			})
		} else {
			components = append(components, map[string]interface{}{
				"type":     "button",
				"sub_type": "url",
				"index":    index,
				"parameters": []map[string]interface{}{
					{"type": "text", "text": value},
				},
			})
		}
	}
	return components
}

// SendFlowMessage sends an interactive WhatsApp Flow message
// flowID is the Meta Flow ID, headerText is optional header, bodyText is the message body,
// ctaText is the button text, flowToken is a unique token for tracking the flow response,
// and firstScreen is the name of the first screen to navigate to
func (c *Client) SendFlowMessage(ctx context.Context, account *Account, phoneNumber, flowID, headerText, bodyText, ctaText, flowToken, firstScreen string) (string, error) {
	if flowID == "" {
		return "", fmt.Errorf("flow ID is required")
	}
	if bodyText == "" {
		return "", fmt.Errorf("body text is required")
	}
	if ctaText == "" {
		ctaText = "Open" // Default CTA text
	}
	if flowToken == "" {
		flowToken = fmt.Sprintf("flow_%d", time.Now().UnixNano())
	}
	if firstScreen == "" {
		firstScreen = "FIRST_SCREEN" // Default fallback
	}

	// Truncate CTA text to 20 chars (WhatsApp limit)
	if len(ctaText) > 20 {
		ctaText = ctaText[:20]
	}

	interactive := map[string]interface{}{
		"type": "flow",
		"body": map[string]interface{}{
			"text": bodyText,
		},
		"action": map[string]interface{}{
			"name": "flow",
			"parameters": map[string]interface{}{
				"flow_message_version": "3",
				"flow_token":           flowToken,
				"flow_id":              flowID,
				"flow_cta":             ctaText,
				"flow_action":          "navigate",
				"flow_action_payload": map[string]interface{}{
					"screen": firstScreen,
				},
			},
		},
	}

	// Add header if provided
	if headerText != "" {
		interactive["header"] = map[string]interface{}{
			"type": "text",
			"text": headerText,
		}
	}

	payload := map[string]interface{}{
		"messaging_product": "whatsapp",
		"recipient_type":    "individual",
		"to":                phoneNumber,
		"type":              "interactive",
		"interactive":       interactive,
	}

	url := c.buildMessagesURL(account)
	c.Log.Debug("Sending flow message", "phone", phoneNumber, "flow_id", flowID)

	respBody, err := c.doRequest(ctx, "POST", url, payload, account.AccessToken)
	if err != nil {
		c.Log.Error("Failed to send flow message", "error", err, "phone", phoneNumber, "flow_id", flowID)
		return "", fmt.Errorf("failed to send flow message: %w", err)
	}

	var resp MetaAPIResponse
	if err := json.Unmarshal(respBody, &resp); err != nil {
		return "", fmt.Errorf("failed to parse response: %w", err)
	}

	if len(resp.Messages) == 0 {
		return "", fmt.Errorf("no message ID in response")
	}

	messageID := resp.Messages[0].ID
	c.Log.Info("Flow message sent", "message_id", messageID, "phone", phoneNumber, "flow_id", flowID)
	return messageID, nil
}

// SendTemplateMessage sends a template message with optional components (header, body, buttons, etc.)
func (c *Client) SendTemplateMessage(ctx context.Context, account *Account, phoneNumber, templateName, languageCode string, components []map[string]interface{}) (string, error) {
	template := map[string]interface{}{
		"name": templateName,
		"language": map[string]interface{}{
			"code": languageCode,
		},
	}

	if len(components) > 0 {
		template["components"] = components
	}

	payload := map[string]interface{}{
		"messaging_product": "whatsapp",
		"to":                phoneNumber,
		"type":              "template",
		"template":          template,
	}

	url := c.buildMessagesURL(account)
	c.Log.Debug("Sending template message with components", "phone", phoneNumber, "template", templateName)

	respBody, err := c.doRequest(ctx, "POST", url, payload, account.AccessToken)
	if err != nil {
		c.Log.Error("Failed to send template message", "error", err, "phone", phoneNumber, "template", templateName)
		return "", fmt.Errorf("failed to send template message: %w", err)
	}

	var resp MetaAPIResponse
	if err := json.Unmarshal(respBody, &resp); err != nil {
		return "", fmt.Errorf("failed to parse response: %w", err)
	}

	if len(resp.Messages) == 0 {
		return "", fmt.Errorf("no message ID in response")
	}

	messageID := resp.Messages[0].ID
	c.Log.Info("Template message sent", "message_id", messageID, "phone", phoneNumber, "template", templateName)
	return messageID, nil
}
